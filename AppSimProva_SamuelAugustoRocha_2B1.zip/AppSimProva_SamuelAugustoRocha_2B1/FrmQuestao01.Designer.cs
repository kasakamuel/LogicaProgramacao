﻿namespace AppSimProva_SamuelAugustoRocha_2B1
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.pnlEsquerda = new System.Windows.Forms.Panel();
            this.pnlDireita = new System.Windows.Forms.Panel();
            this.lblQuestao01 = new System.Windows.Forms.Label();
            this.lblProduto1 = new System.Windows.Forms.Label();
            this.lblProduto2 = new System.Windows.Forms.Label();
            this.lblProduto3 = new System.Windows.Forms.Label();
            this.txtProduto1 = new System.Windows.Forms.TextBox();
            this.txtProduto2 = new System.Windows.Forms.TextBox();
            this.txtProduto3 = new System.Windows.Forms.TextBox();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.lblParcela1 = new System.Windows.Forms.Label();
            this.lblParcela2 = new System.Windows.Forms.Label();
            this.lblParcela3 = new System.Windows.Forms.Label();
            this.lblParcela4 = new System.Windows.Forms.Label();
            this.lblParcela5 = new System.Windows.Forms.Label();
            this.lblResultParc1 = new System.Windows.Forms.Label();
            this.lblResultParc2 = new System.Windows.Forms.Label();
            this.lblResultParc3 = new System.Windows.Forms.Label();
            this.lblResultParc4 = new System.Windows.Forms.Label();
            this.lblResultParc5 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTitulo.SuspendLayout();
            this.pnlEsquerda.SuspendLayout();
            this.pnlDireita.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(163)))), ((int)(((byte)(17)))));
            this.pnlTitulo.Controls.Add(this.lblQuestao01);
            this.pnlTitulo.Location = new System.Drawing.Point(-1, 0);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(805, 90);
            this.pnlTitulo.TabIndex = 0;
            // 
            // pnlEsquerda
            // 
            this.pnlEsquerda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(163)))), ((int)(((byte)(17)))));
            this.pnlEsquerda.Controls.Add(this.txtPreco1);
            this.pnlEsquerda.Controls.Add(this.txtPreco2);
            this.pnlEsquerda.Controls.Add(this.txtPreco3);
            this.pnlEsquerda.Controls.Add(this.lblPreco3);
            this.pnlEsquerda.Controls.Add(this.lblPreco2);
            this.pnlEsquerda.Controls.Add(this.lblPreco1);
            this.pnlEsquerda.Controls.Add(this.txtProduto3);
            this.pnlEsquerda.Controls.Add(this.txtProduto2);
            this.pnlEsquerda.Controls.Add(this.txtProduto1);
            this.pnlEsquerda.Controls.Add(this.lblProduto3);
            this.pnlEsquerda.Controls.Add(this.lblProduto2);
            this.pnlEsquerda.Controls.Add(this.lblProduto1);
            this.pnlEsquerda.Location = new System.Drawing.Point(29, 118);
            this.pnlEsquerda.Name = "pnlEsquerda";
            this.pnlEsquerda.Size = new System.Drawing.Size(426, 264);
            this.pnlEsquerda.TabIndex = 1;
            // 
            // pnlDireita
            // 
            this.pnlDireita.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(163)))), ((int)(((byte)(17)))));
            this.pnlDireita.Controls.Add(this.lblResultParc5);
            this.pnlDireita.Controls.Add(this.lblResultParc4);
            this.pnlDireita.Controls.Add(this.lblResultParc3);
            this.pnlDireita.Controls.Add(this.lblResultParc2);
            this.pnlDireita.Controls.Add(this.lblResultParc1);
            this.pnlDireita.Controls.Add(this.lblParcela5);
            this.pnlDireita.Controls.Add(this.lblParcela4);
            this.pnlDireita.Controls.Add(this.lblParcela3);
            this.pnlDireita.Controls.Add(this.lblParcela2);
            this.pnlDireita.Controls.Add(this.lblParcela1);
            this.pnlDireita.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlDireita.Location = new System.Drawing.Point(536, 118);
            this.pnlDireita.Name = "pnlDireita";
            this.pnlDireita.Size = new System.Drawing.Size(228, 264);
            this.pnlDireita.TabIndex = 2;
            this.pnlDireita.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // lblQuestao01
            // 
            this.lblQuestao01.AutoSize = true;
            this.lblQuestao01.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestao01.Location = new System.Drawing.Point(46, 25);
            this.lblQuestao01.Name = "lblQuestao01";
            this.lblQuestao01.Size = new System.Drawing.Size(147, 31);
            this.lblQuestao01.TabIndex = 0;
            this.lblQuestao01.Text = "Questão01";
            // 
            // lblProduto1
            // 
            this.lblProduto1.AutoSize = true;
            this.lblProduto1.Location = new System.Drawing.Point(42, 43);
            this.lblProduto1.Name = "lblProduto1";
            this.lblProduto1.Size = new System.Drawing.Size(50, 13);
            this.lblProduto1.TabIndex = 0;
            this.lblProduto1.Text = "Produto1";
            // 
            // lblProduto2
            // 
            this.lblProduto2.AutoSize = true;
            this.lblProduto2.Location = new System.Drawing.Point(42, 111);
            this.lblProduto2.Name = "lblProduto2";
            this.lblProduto2.Size = new System.Drawing.Size(50, 13);
            this.lblProduto2.TabIndex = 1;
            this.lblProduto2.Text = "Produto2";
            // 
            // lblProduto3
            // 
            this.lblProduto3.AutoSize = true;
            this.lblProduto3.Location = new System.Drawing.Point(42, 179);
            this.lblProduto3.Name = "lblProduto3";
            this.lblProduto3.Size = new System.Drawing.Size(50, 13);
            this.lblProduto3.TabIndex = 2;
            this.lblProduto3.Text = "Produto3";
            // 
            // txtProduto1
            // 
            this.txtProduto1.Location = new System.Drawing.Point(45, 70);
            this.txtProduto1.Name = "txtProduto1";
            this.txtProduto1.Size = new System.Drawing.Size(100, 20);
            this.txtProduto1.TabIndex = 3;
            // 
            // txtProduto2
            // 
            this.txtProduto2.Location = new System.Drawing.Point(45, 137);
            this.txtProduto2.Name = "txtProduto2";
            this.txtProduto2.Size = new System.Drawing.Size(100, 20);
            this.txtProduto2.TabIndex = 4;
            // 
            // txtProduto3
            // 
            this.txtProduto3.Location = new System.Drawing.Point(45, 207);
            this.txtProduto3.Name = "txtProduto3";
            this.txtProduto3.Size = new System.Drawing.Size(100, 20);
            this.txtProduto3.TabIndex = 5;
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.Location = new System.Drawing.Point(250, 43);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(41, 13);
            this.lblPreco1.TabIndex = 6;
            this.lblPreco1.Text = "Preço1";
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Location = new System.Drawing.Point(250, 111);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(41, 13);
            this.lblPreco2.TabIndex = 7;
            this.lblPreco2.Text = "Preço2";
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Location = new System.Drawing.Point(250, 179);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(41, 13);
            this.lblPreco3.TabIndex = 8;
            this.lblPreco3.Text = "Preço3";
            // 
            // txtPreco3
            // 
            this.txtPreco3.Location = new System.Drawing.Point(253, 207);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(100, 20);
            this.txtPreco3.TabIndex = 9;
            // 
            // txtPreco2
            // 
            this.txtPreco2.Location = new System.Drawing.Point(253, 137);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(100, 20);
            this.txtPreco2.TabIndex = 10;
            // 
            // txtPreco1
            // 
            this.txtPreco1.Location = new System.Drawing.Point(253, 70);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(100, 20);
            this.txtPreco1.TabIndex = 11;
            // 
            // lblParcela1
            // 
            this.lblParcela1.AutoSize = true;
            this.lblParcela1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela1.Location = new System.Drawing.Point(24, 43);
            this.lblParcela1.Name = "lblParcela1";
            this.lblParcela1.Size = new System.Drawing.Size(110, 20);
            this.lblParcela1.TabIndex = 0;
            this.lblParcela1.Text = "01 Parcela de:";
            // 
            // lblParcela2
            // 
            this.lblParcela2.AutoSize = true;
            this.lblParcela2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela2.Location = new System.Drawing.Point(24, 77);
            this.lblParcela2.Name = "lblParcela2";
            this.lblParcela2.Size = new System.Drawing.Size(110, 20);
            this.lblParcela2.TabIndex = 1;
            this.lblParcela2.Text = "02 Parcela de:";
            // 
            // lblParcela3
            // 
            this.lblParcela3.AutoSize = true;
            this.lblParcela3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela3.Location = new System.Drawing.Point(24, 111);
            this.lblParcela3.Name = "lblParcela3";
            this.lblParcela3.Size = new System.Drawing.Size(110, 20);
            this.lblParcela3.TabIndex = 2;
            this.lblParcela3.Text = "03 Parcela de:";
            // 
            // lblParcela4
            // 
            this.lblParcela4.AutoSize = true;
            this.lblParcela4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela4.Location = new System.Drawing.Point(24, 144);
            this.lblParcela4.Name = "lblParcela4";
            this.lblParcela4.Size = new System.Drawing.Size(110, 20);
            this.lblParcela4.TabIndex = 3;
            this.lblParcela4.Text = "04 Parcela de:";
            // 
            // lblParcela5
            // 
            this.lblParcela5.AutoSize = true;
            this.lblParcela5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela5.Location = new System.Drawing.Point(24, 179);
            this.lblParcela5.Name = "lblParcela5";
            this.lblParcela5.Size = new System.Drawing.Size(110, 20);
            this.lblParcela5.TabIndex = 4;
            this.lblParcela5.Text = "05 Parcela de:";
            // 
            // lblResultParc1
            // 
            this.lblResultParc1.AutoSize = true;
            this.lblResultParc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultParc1.Location = new System.Drawing.Point(151, 43);
            this.lblResultParc1.Name = "lblResultParc1";
            this.lblResultParc1.Size = new System.Drawing.Size(14, 20);
            this.lblResultParc1.TabIndex = 5;
            this.lblResultParc1.Text = "-";
            // 
            // lblResultParc2
            // 
            this.lblResultParc2.AutoSize = true;
            this.lblResultParc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultParc2.Location = new System.Drawing.Point(151, 77);
            this.lblResultParc2.Name = "lblResultParc2";
            this.lblResultParc2.Size = new System.Drawing.Size(14, 20);
            this.lblResultParc2.TabIndex = 6;
            this.lblResultParc2.Text = "-";
            // 
            // lblResultParc3
            // 
            this.lblResultParc3.AutoSize = true;
            this.lblResultParc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultParc3.Location = new System.Drawing.Point(151, 111);
            this.lblResultParc3.Name = "lblResultParc3";
            this.lblResultParc3.Size = new System.Drawing.Size(14, 20);
            this.lblResultParc3.TabIndex = 7;
            this.lblResultParc3.Text = "-";
            // 
            // lblResultParc4
            // 
            this.lblResultParc4.AutoSize = true;
            this.lblResultParc4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultParc4.Location = new System.Drawing.Point(151, 144);
            this.lblResultParc4.Name = "lblResultParc4";
            this.lblResultParc4.Size = new System.Drawing.Size(14, 20);
            this.lblResultParc4.TabIndex = 8;
            this.lblResultParc4.Text = "-";
            // 
            // lblResultParc5
            // 
            this.lblResultParc5.AutoSize = true;
            this.lblResultParc5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultParc5.Location = new System.Drawing.Point(151, 179);
            this.lblResultParc5.Name = "lblResultParc5";
            this.lblResultParc5.Size = new System.Drawing.Size(14, 20);
            this.lblResultParc5.TabIndex = 9;
            this.lblResultParc5.Text = "-";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(341, 399);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(157, 39);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.pnlDireita);
            this.Controls.Add(this.pnlEsquerda);
            this.Controls.Add(this.pnlTitulo);
            this.Name = "FrmQuestao01";
            this.Text = "Questão01";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.pnlEsquerda.ResumeLayout(false);
            this.pnlEsquerda.PerformLayout();
            this.pnlDireita.ResumeLayout(false);
            this.pnlDireita.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblQuestao01;
        private System.Windows.Forms.Panel pnlEsquerda;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.Label lblPreco1;
        private System.Windows.Forms.TextBox txtProduto3;
        private System.Windows.Forms.TextBox txtProduto2;
        private System.Windows.Forms.TextBox txtProduto1;
        private System.Windows.Forms.Label lblProduto3;
        private System.Windows.Forms.Label lblProduto2;
        private System.Windows.Forms.Label lblProduto1;
        private System.Windows.Forms.Panel pnlDireita;
        private System.Windows.Forms.Label lblResultParc5;
        private System.Windows.Forms.Label lblResultParc4;
        private System.Windows.Forms.Label lblResultParc3;
        private System.Windows.Forms.Label lblResultParc2;
        private System.Windows.Forms.Label lblResultParc1;
        private System.Windows.Forms.Label lblParcela5;
        private System.Windows.Forms.Label lblParcela4;
        private System.Windows.Forms.Label lblParcela3;
        private System.Windows.Forms.Label lblParcela2;
        private System.Windows.Forms.Label lblParcela1;
        private System.Windows.Forms.Button btnCalcular;
    }
}

