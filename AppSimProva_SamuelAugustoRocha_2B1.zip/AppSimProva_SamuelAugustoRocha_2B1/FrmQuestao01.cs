﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_SamuelAugustoRocha_2B1
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar dados da tela
            float preco1 = float.Parse(txtPreco1.Text);
            float preco2 = float.Parse(txtPreco2.Text);
            float preco3 = float.Parse(txtPreco3.Text);
            float valorCompra;

            //Calcular o valor da compra
            valorCompra = preco1 + preco2 + preco3;

            //Mostrar resultados nas labels
            lblResultParc1.Text = (valorCompra/1).ToString("C");
            lblResultParc2.Text = (valorCompra / 2).ToString("C");
            lblResultParc3.Text = (valorCompra / 3).ToString("C");
            lblResultParc4.Text = (valorCompra / 4).ToString("C");
            lblResultParc5.Text = (valorCompra / 5).ToString("C");
        }
    }
}
