﻿namespace AppTestePratico_SamuelAugusto2B1
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao01));
            this.txtQtdPao = new System.Windows.Forms.TextBox();
            this.txtQtdBroa = new System.Windows.Forms.TextBox();
            this.lblQtdPao = new System.Windows.Forms.Label();
            this.lblQtdBroa = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblQuestao1 = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblLegenda = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtQtdPao
            // 
            this.txtQtdPao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdPao.Location = new System.Drawing.Point(158, 185);
            this.txtQtdPao.Name = "txtQtdPao";
            this.txtQtdPao.Size = new System.Drawing.Size(192, 26);
            this.txtQtdPao.TabIndex = 0;
            // 
            // txtQtdBroa
            // 
            this.txtQtdBroa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdBroa.Location = new System.Drawing.Point(158, 292);
            this.txtQtdBroa.Name = "txtQtdBroa";
            this.txtQtdBroa.Size = new System.Drawing.Size(192, 26);
            this.txtQtdBroa.TabIndex = 1;
            // 
            // lblQtdPao
            // 
            this.lblQtdPao.AutoSize = true;
            this.lblQtdPao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdPao.Location = new System.Drawing.Point(153, 134);
            this.lblQtdPao.Name = "lblQtdPao";
            this.lblQtdPao.Size = new System.Drawing.Size(195, 25);
            this.lblQtdPao.TabIndex = 2;
            this.lblQtdPao.Text = "Quantidade de pão";
            // 
            // lblQtdBroa
            // 
            this.lblQtdBroa.AutoSize = true;
            this.lblQtdBroa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdBroa.Location = new System.Drawing.Point(153, 244);
            this.lblQtdBroa.Name = "lblQtdBroa";
            this.lblQtdBroa.Size = new System.Drawing.Size(202, 25);
            this.lblQtdBroa.TabIndex = 3;
            this.lblQtdBroa.Text = "Quantidade de broa";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(29)))), ((int)(((byte)(27)))));
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.SystemColors.Control;
            this.btnCalcular.Location = new System.Drawing.Point(512, 230);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(125, 46);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblQuestao1
            // 
            this.lblQuestao1.AutoSize = true;
            this.lblQuestao1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestao1.ForeColor = System.Drawing.SystemColors.Control;
            this.lblQuestao1.Location = new System.Drawing.Point(40, 26);
            this.lblQuestao1.Name = "lblQuestao1";
            this.lblQuestao1.Size = new System.Drawing.Size(147, 31);
            this.lblQuestao1.TabIndex = 5;
            this.lblQuestao1.Text = "Questão01";
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(88)))), ((int)(((byte)(42)))));
            this.pnlTop.Controls.Add(this.lblQuestao1);
            this.pnlTop.Location = new System.Drawing.Point(-1, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(802, 90);
            this.pnlTop.TabIndex = 6;
            // 
            // lblLegenda
            // 
            this.lblLegenda.AutoSize = true;
            this.lblLegenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegenda.Location = new System.Drawing.Point(372, 374);
            this.lblLegenda.Name = "lblLegenda";
            this.lblLegenda.Size = new System.Drawing.Size(147, 25);
            this.lblLegenda.TabIndex = 7;
            this.lblLegenda.Text = "Valor a pagar:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(623, 374);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(46, 25);
            this.lblResultado.TabIndex = 8;
            this.lblResultado.Text = "R$-";
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(148)))), ((int)(((byte)(87)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblLegenda);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblQtdBroa);
            this.Controls.Add(this.lblQtdPao);
            this.Controls.Add(this.txtQtdBroa);
            this.Controls.Add(this.txtQtdPao);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao01";
            this.Text = "Padaria";
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtQtdPao;
        private System.Windows.Forms.TextBox txtQtdBroa;
        private System.Windows.Forms.Label lblQtdPao;
        private System.Windows.Forms.Label lblQtdBroa;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblQuestao1;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblLegenda;
        private System.Windows.Forms.Label lblResultado;
    }
}

