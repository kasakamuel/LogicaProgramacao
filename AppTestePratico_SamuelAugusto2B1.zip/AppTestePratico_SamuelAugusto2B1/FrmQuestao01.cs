﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_SamuelAugusto2B1
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int qtdPao = int.Parse(txtQtdPao.Text);
            int qtdBroa = int.Parse(txtQtdBroa.Text);
            float total;

            //Fazer o cálculo
            total = qtdBroa * 1.50f + qtdPao * 0.12f;

            //Mostrar resultado em label
            lblResultado.Text = "R$" + total;


        }
    }
}
