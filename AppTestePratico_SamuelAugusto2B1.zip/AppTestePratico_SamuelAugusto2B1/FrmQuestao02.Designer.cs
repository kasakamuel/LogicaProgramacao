﻿namespace AppTestePratico_SamuelAugusto2B1
{
    partial class FrmQuestao02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblQtdCamisasP = new System.Windows.Forms.Label();
            this.lblQtdCamisasM = new System.Windows.Forms.Label();
            this.lblQtdCamisasG = new System.Windows.Forms.Label();
            this.txtQtdCamisasP = new System.Windows.Forms.TextBox();
            this.txtQtdCamisasM = new System.Windows.Forms.TextBox();
            this.txtQtdCamisasG = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValor = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblQuestao02 = new System.Windows.Forms.Label();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblQtdCamisasP
            // 
            this.lblQtdCamisasP.AutoSize = true;
            this.lblQtdCamisasP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCamisasP.Location = new System.Drawing.Point(87, 154);
            this.lblQtdCamisasP.Name = "lblQtdCamisasP";
            this.lblQtdCamisasP.Size = new System.Drawing.Size(115, 25);
            this.lblQtdCamisasP.TabIndex = 0;
            this.lblQtdCamisasP.Text = "Camisas P";
            // 
            // lblQtdCamisasM
            // 
            this.lblQtdCamisasM.AutoSize = true;
            this.lblQtdCamisasM.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCamisasM.Location = new System.Drawing.Point(87, 225);
            this.lblQtdCamisasM.Name = "lblQtdCamisasM";
            this.lblQtdCamisasM.Size = new System.Drawing.Size(119, 25);
            this.lblQtdCamisasM.TabIndex = 1;
            this.lblQtdCamisasM.Text = "Camisas M";
            // 
            // lblQtdCamisasG
            // 
            this.lblQtdCamisasG.AutoSize = true;
            this.lblQtdCamisasG.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCamisasG.Location = new System.Drawing.Point(87, 301);
            this.lblQtdCamisasG.Name = "lblQtdCamisasG";
            this.lblQtdCamisasG.Size = new System.Drawing.Size(117, 25);
            this.lblQtdCamisasG.TabIndex = 2;
            this.lblQtdCamisasG.Text = "Camisas G";
            // 
            // txtQtdCamisasP
            // 
            this.txtQtdCamisasP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdCamisasP.Location = new System.Drawing.Point(92, 182);
            this.txtQtdCamisasP.Name = "txtQtdCamisasP";
            this.txtQtdCamisasP.Size = new System.Drawing.Size(127, 26);
            this.txtQtdCamisasP.TabIndex = 3;
            this.txtQtdCamisasP.TextChanged += new System.EventHandler(this.txtQtdCamisasP_TextChanged);
            // 
            // txtQtdCamisasM
            // 
            this.txtQtdCamisasM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdCamisasM.Location = new System.Drawing.Point(92, 262);
            this.txtQtdCamisasM.Name = "txtQtdCamisasM";
            this.txtQtdCamisasM.Size = new System.Drawing.Size(127, 26);
            this.txtQtdCamisasM.TabIndex = 4;
            // 
            // txtQtdCamisasG
            // 
            this.txtQtdCamisasG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdCamisasG.Location = new System.Drawing.Point(92, 339);
            this.txtQtdCamisasG.Name = "txtQtdCamisasG";
            this.txtQtdCamisasG.Size = new System.Drawing.Size(127, 26);
            this.txtQtdCamisasG.TabIndex = 5;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(42)))), ((int)(((byte)(43)))));
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(444, 243);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(104, 45);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(441, 352);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(68, 25);
            this.lblValor.TabIndex = 7;
            this.lblValor.Text = "Valor:";
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(92)))), ((int)(((byte)(103)))));
            this.pnlTop.Controls.Add(this.lblQuestao02);
            this.pnlTop.Location = new System.Drawing.Point(-1, -2);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(803, 102);
            this.pnlTop.TabIndex = 8;
            // 
            // lblQuestao02
            // 
            this.lblQuestao02.AutoSize = true;
            this.lblQuestao02.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestao02.ForeColor = System.Drawing.Color.White;
            this.lblQuestao02.Location = new System.Drawing.Point(41, 35);
            this.lblQuestao02.Name = "lblQuestao02";
            this.lblQuestao02.Size = new System.Drawing.Size(147, 31);
            this.lblQuestao02.TabIndex = 0;
            this.lblQuestao02.Text = "Questão02";
            // 
            // FrmQuestao02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(159)))), ((int)(((byte)(62)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.lblValor);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtQtdCamisasG);
            this.Controls.Add(this.txtQtdCamisasM);
            this.Controls.Add(this.txtQtdCamisasP);
            this.Controls.Add(this.lblQtdCamisasG);
            this.Controls.Add(this.lblQtdCamisasM);
            this.Controls.Add(this.lblQtdCamisasP);
            this.Name = "FrmQuestao02";
            this.Text = "Questao02";
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQtdCamisasP;
        private System.Windows.Forms.Label lblQtdCamisasM;
        private System.Windows.Forms.Label lblQtdCamisasG;
        private System.Windows.Forms.TextBox txtQtdCamisasP;
        private System.Windows.Forms.TextBox txtQtdCamisasM;
        private System.Windows.Forms.TextBox txtQtdCamisasG;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblQuestao02;
    }
}