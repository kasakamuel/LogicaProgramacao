﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_SamuelAugusto2B1
{
    public partial class FrmQuestao02 : Form
    {
        public FrmQuestao02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int qtdCamisasP = int.Parse(txtQtdCamisasP.Text);
            int qtdCamisasM = int.Parse(txtQtdCamisasM.Text);
            int qtdCamisasG = int.Parse(txtQtdCamisasG.Text);
            float total;

            //Fazer o cálculo
            total = qtdCamisasP * qtdCamisasM * qtdCamisasG * 22;

            //Mostrar resultado em label
            lblValor.Text = "Valor:" + total;
        }

        private void txtQtdCamisasP_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
