﻿namespace ProjetoCalculadora
{
    partial class FrmCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCalculadora));
            this.txtNumUm = new System.Windows.Forms.TextBox();
            this.txtNumDois = new System.Windows.Forms.TextBox();
            this.lblNumUm = new System.Windows.Forms.Label();
            this.lblNumDois = new System.Windows.Forms.Label();
            this.btnSomar = new System.Windows.Forms.Button();
            this.btnSubtrair = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNumUm
            // 
            this.txtNumUm.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumUm.Location = new System.Drawing.Point(82, 79);
            this.txtNumUm.Name = "txtNumUm";
            this.txtNumUm.Size = new System.Drawing.Size(378, 62);
            this.txtNumUm.TabIndex = 0;
            // 
            // txtNumDois
            // 
            this.txtNumDois.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumDois.Location = new System.Drawing.Point(82, 220);
            this.txtNumDois.Name = "txtNumDois";
            this.txtNumDois.Size = new System.Drawing.Size(378, 62);
            this.txtNumDois.TabIndex = 1;
            // 
            // lblNumUm
            // 
            this.lblNumUm.AutoSize = true;
            this.lblNumUm.BackColor = System.Drawing.Color.Transparent;
            this.lblNumUm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumUm.ForeColor = System.Drawing.Color.White;
            this.lblNumUm.Location = new System.Drawing.Point(88, 30);
            this.lblNumUm.Name = "lblNumUm";
            this.lblNumUm.Size = new System.Drawing.Size(68, 25);
            this.lblNumUm.TabIndex = 2;
            this.lblNumUm.Text = "Num1";
            // 
            // lblNumDois
            // 
            this.lblNumDois.AutoSize = true;
            this.lblNumDois.BackColor = System.Drawing.Color.Transparent;
            this.lblNumDois.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumDois.ForeColor = System.Drawing.Color.White;
            this.lblNumDois.Location = new System.Drawing.Point(88, 173);
            this.lblNumDois.Name = "lblNumDois";
            this.lblNumDois.Size = new System.Drawing.Size(68, 25);
            this.lblNumDois.TabIndex = 3;
            this.lblNumDois.Text = "Num2";
            // 
            // btnSomar
            // 
            this.btnSomar.BackColor = System.Drawing.SystemColors.Control;
            this.btnSomar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSomar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSomar.ForeColor = System.Drawing.Color.Black;
            this.btnSomar.Location = new System.Drawing.Point(82, 311);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(70, 45);
            this.btnSomar.TabIndex = 4;
            this.btnSomar.Text = "+";
            this.btnSomar.UseVisualStyleBackColor = false;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // btnSubtrair
            // 
            this.btnSubtrair.BackColor = System.Drawing.SystemColors.Control;
            this.btnSubtrair.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubtrair.Location = new System.Drawing.Point(190, 311);
            this.btnSubtrair.Name = "btnSubtrair";
            this.btnSubtrair.Size = new System.Drawing.Size(70, 45);
            this.btnSubtrair.TabIndex = 5;
            this.btnSubtrair.Text = "-";
            this.btnSubtrair.UseVisualStyleBackColor = false;
            this.btnSubtrair.Click += new System.EventHandler(this.btnSubtrair_Click);
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplicar.Location = new System.Drawing.Point(291, 311);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(70, 45);
            this.btnMultiplicar.TabIndex = 6;
            this.btnMultiplicar.Text = "*";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            this.btnMultiplicar.Click += new System.EventHandler(this.btnMultiplicar_Click);
            // 
            // btnDividir
            // 
            this.btnDividir.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDividir.Location = new System.Drawing.Point(390, 311);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(70, 45);
            this.btnDividir.TabIndex = 7;
            this.btnDividir.Text = "/";
            this.btnDividir.UseVisualStyleBackColor = true;
            this.btnDividir.Click += new System.EventHandler(this.btnDividir_Click);
            // 
            // FrmCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjetoCalculadora.Properties.Resources._9c4c064f2263249de7cef1c49162597d_desenho_de_fundo_abstrato_preto;
            this.ClientSize = new System.Drawing.Size(533, 450);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.btnSubtrair);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.lblNumDois);
            this.Controls.Add(this.lblNumUm);
            this.Controls.Add(this.txtNumDois);
            this.Controls.Add(this.txtNumUm);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmCalculadora";
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNumUm;
        private System.Windows.Forms.TextBox txtNumDois;
        private System.Windows.Forms.Label lblNumUm;
        private System.Windows.Forms.Label lblNumDois;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.Button btnSubtrair;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Button btnDividir;
    }
}

